package com.example.rest_api_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
